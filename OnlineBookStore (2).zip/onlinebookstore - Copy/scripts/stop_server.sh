#!/bin/bash
cd /opt/tomcat8/bin
./shutdown.sh
